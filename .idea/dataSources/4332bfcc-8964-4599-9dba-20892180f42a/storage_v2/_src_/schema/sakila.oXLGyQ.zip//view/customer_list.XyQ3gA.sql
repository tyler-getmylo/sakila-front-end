create definer = root@localhost view customer_list as
select `cu`.`customer_id`                               as `ID`,
       concat(`cu`.`first_name`, ' ', `cu`.`last_name`) as `name`,
       `a`.`address`                                    as `address`,
       `a`.`postal_code`                                as `zip code`,
       `a`.`phone`                                      as `phone`,
       `sakila`.`city`.`city`                           as `city`,
       `sakila`.`country`.`country`                     as `country`,
       if(`cu`.`active`, 'active', '')                  as `notes`,
       `cu`.`store_id`                                  as `SID`
from (((`sakila`.`customer` `cu` join `sakila`.`address` `a`
        on ((`cu`.`address_id` = `a`.`address_id`))) join `sakila`.`city`
       on ((`a`.`city_id` = `sakila`.`city`.`city_id`))) join `sakila`.`country`
      on ((`sakila`.`city`.`country_id` = `sakila`.`country`.`country_id`)));

