create definer = root@localhost view staff_list as
select `s`.`staff_id`                                 as `ID`,
       concat(`s`.`first_name`, ' ', `s`.`last_name`) as `name`,
       `a`.`address`                                  as `address`,
       `a`.`postal_code`                              as `zip code`,
       `a`.`phone`                                    as `phone`,
       `sakila`.`city`.`city`                         as `city`,
       `sakila`.`country`.`country`                   as `country`,
       `s`.`store_id`                                 as `SID`
from (((`sakila`.`staff` `s` join `sakila`.`address` `a`
        on ((`s`.`address_id` = `a`.`address_id`))) join `sakila`.`city`
       on ((`a`.`city_id` = `sakila`.`city`.`city_id`))) join `sakila`.`country`
      on ((`sakila`.`city`.`country_id` = `sakila`.`country`.`country_id`)));

